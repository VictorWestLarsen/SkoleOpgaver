﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinterTest2019
{
    public class Player : Person
    {

        private List<int> scores = new List<int>();

        private string firstName;
        private string lastName;

        public Player(string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
        }

       public void RegisterScore(int score)
        {
            scores.Add(score);
        }

        public bool HasScoreOfOne()
        {

            if (scores.Contains(1))
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
