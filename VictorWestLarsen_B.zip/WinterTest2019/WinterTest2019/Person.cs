﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinterTest2019
{
    public class Person
    {

        public string FirstName
        {
            get;
            set;
        }
        public string LastName
        {
            get;
            set;
        }
        public string fullname;
        public string FullName
        {
            get
            {
                return FirstName + " " + LastName;
            }
        }

        public Person() : base()
        {

        }

        public Person(string firstname)
        {
            this.FirstName = firstname;
        }

        public Person(string firstname, string lastname)
        {
            this.FirstName = firstname;
            this.LastName = lastname;

            
        }
    }
}
